from machine import Pin
from utime import sleep

Button = Pin(15, Pin.IN, Pin.PULL_UP)
Led = Pin(25, Pin.OUT)

while True:
  if Button() == False :
    Led.high()
    sleep(0.25)
  else:
    Led.low()
    sleep(0.25)


