from machine import Pin
from utime import sleep

led_V = Pin(0, Pin.OUT)
led_G = Pin(1, Pin.OUT)
led_R = Pin(2, Pin.OUT)

while True:
  led_V.toggle()
  sleep(5)
  led_G.toggle()
  sleep(2)
  led_G.toggle()
  led_R.toggle()
  led_V.toggle()
  sleep(8)
  led_R.toggle()