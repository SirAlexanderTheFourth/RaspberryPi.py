from machine import Pin
from utime import sleep

led = Pin(2, Pin.OUT)
while True:
  led.toggle()
  sleep(0.25)
  print("Hello, world!")
  led.toggle()
  sleep(0.25)