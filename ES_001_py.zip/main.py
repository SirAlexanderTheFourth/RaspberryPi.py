from machine import Pin
from utime import sleep
led=Pin(25, Pin.OUT)

while True:
  led.toggle()
  print("hello, world!")
  sleep(0.5)


