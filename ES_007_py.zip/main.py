from machine import Pin
from utime import sleep

F=100
led = Pin(1, Pin.OUT)
d=1
ta=(d/F)
ts=((1-d)/F)
while True:
  led.high()
  print(ta)
  sleep(ta)
  led.low()
  print(ts)
  sleep(ts)
