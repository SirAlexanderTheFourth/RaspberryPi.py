from machine import Pin
from machine import ADC
from utime import sleep

conversion_factor = 3.3 / (65536)
adc_read = ADC(28)
led_1 = Pin(1, Pin.OUT)
led_2 = Pin(2, Pin.OUT)
led_3 = Pin(3, Pin.OUT)
led_4 = Pin(4, Pin.OUT)
led_5 = Pin(5, Pin.OUT)
led_6 = Pin(6, Pin.OUT)

while True:
  reading = adc_read.read_u16()
  V = reading * conversion_factor
  print("Tensione letta sul pin GP28: ", V,"V")
  if V < 0.55:
      led_1.low()
      led_2.low()
      led_3.low()
      led_4.low()
      led_5.low()
      led_6.low()
  elif V >= 0.55 and V < 1.10:
      led_1.high()
      led_2.low()
      led_3.low()
      led_4.low()
      led_5.low()
      led_6.low()
    
  elif V >=1.10 and V <1.65 :
      led_1.high()
      led_2.high()
      led_3.low()
      led_4.low()
      led_5.low()
      led_6.low()
  elif V >=1.65 and V < 2.20 :
      led_1.high()
      led_2.high()
      led_3.high()
      led_4.low()
      led_5.low()
      led_6.low()
  elif V >=2.20 and V <2.75 :
      led_1.high()
      led_2.high()
      led_3.high()
      led_4.high()
      led_5.low()
      led_6.low()
  elif V >=2.75 and V <3.2 :
      led_1.high()
      led_2.high()
      led_3.high()
      led_4.high()
      led_5.high()
      led_6.low()
  elif V >= 3.2 :
      led_1.high()
      led_2.high()
      led_3.high()
      led_4.high()
      led_5.high()
      led_6.high()
  sleep(0.1)

