from machine import Pin
from machine import ADC
from utime import sleep


adc_read = ADC(28)
led = Pin(1, Pin.OUT)
conversion_factor = 3.3 / (65536)
F=100


while True:
  reading = adc_read.read_u16()
  V = reading * conversion_factor
  d= V / 3.3
  ta=(d/F)
  ts=((1-d)/F)
  led.high()
  print(ta)
  sleep(ta)
  led.low()
  print(ts)
  sleep(ts)