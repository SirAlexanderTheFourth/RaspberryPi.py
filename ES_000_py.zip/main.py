from utime import sleep 

while True:
  print("Hello, world \n")
  print("Ciao mondo! \n")
  sleep(1)
